
    <?php
        use Illuminate\Support\Facades\Schema;
        use Illuminate\Database\Schema\Blueprint;
        use Illuminate\Database\Migrations\Migration;
        
        class CreateItemsTable extends Migration
        {
            /**
             * Run the migrations.
             *
             * @return void
             */
            public function up()
            {
                Schema::create("items", function (Blueprint $table) {

						$table->bigIncrements('id');
						$table->integer('project_id')->nullable()->unsigned();
						$table->integer('category_id')->nullable()->unsigned();
						$table->integer('item_name')->nullable();
						$table->integer('unit_num')->nullable();
						//$table->foreign("project_id")->references("id")->on("projects");
						//$table->foreign("category_id")->references("id")->on("itemkinds");



						// ----------------------------------------------------
						// -- SELECT [items]--
						// ----------------------------------------------------
						// $query = DB::table("items")
						// ->leftJoin("projects","projects.id", "=", "items.project_id")
						// ->leftJoin("itemkinds","itemkinds.id", "=", "items.category_id")
						// ->get();
						// dd($query); //For checking



                });
            }

            /**
             * Reverse the migrations.
             *
             * @return void
             */
            public function down()
            {
                Schema::dropIfExists("items");
            }
        }
    