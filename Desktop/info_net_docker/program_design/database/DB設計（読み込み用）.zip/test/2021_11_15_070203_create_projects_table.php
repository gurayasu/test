
    <?php
        use Illuminate\Support\Facades\Schema;
        use Illuminate\Database\Schema\Blueprint;
        use Illuminate\Database\Migrations\Migration;
        
        class CreateProjectsTable extends Migration
        {
            /**
             * Run the migrations.
             *
             * @return void
             */
            public function up()
            {
                Schema::create("projects", function (Blueprint $table) {

						$table->bigIncrements('id');
						$table->string('name',254)->nullable();
						$table->integer('makerid')->nullable()->unsigned();
						$table->datetime('endline')->nullable();
						$table->integer('total')->nullable();
						$table->text('comment')->nullable();
						$table->timestamps();
						$table->integer('status')->nullable();
						

                    //*********************************
                    // Foreign KEY [ Uncomment if you want to use!! ]
                    //*********************************
                        //$table->foreign("makerid")->references("id")->on("users");



						// ----------------------------------------------------
						// -- SELECT [projects]--
						// ----------------------------------------------------
						// $query = DB::table("projects")
						// ->leftJoin("users","users.id", "=", "projects.makerid")
						// ->get();
						// dd($query); //For checking



                });
            }

            /**
             * Reverse the migrations.
             *
             * @return void
             */
            public function down()
            {
                Schema::dropIfExists("projects");
            }
        }
    