
    <?php
        use Illuminate\Support\Facades\Schema;
        use Illuminate\Database\Schema\Blueprint;
        use Illuminate\Database\Migrations\Migration;
        
        class CreateEstimatesTable extends Migration
        {
            /**
             * Run the migrations.
             *
             * @return void
             */
            public function up()
            {
                Schema::create("estimates", function (Blueprint $table) {

						$table->bigIncrements('id');
						$table->integer('item_id')->nullable()->unsigned();
						$table->integer('order_user_id')->nullable()->unsigned();
						$table->bigInteger('unit_price')->nullable();
						$table->bigInteger('order_price')->nullable();
						$table->tinyInteger('certification')->nullable(); //採用するかどうか
						//$table->foreign("item_id")->references("id")->on("items");
						//$table->foreign("order_user_id")->references("id")->on("users");



						// ----------------------------------------------------
						// -- SELECT [estimates]--
						// ----------------------------------------------------
						// $query = DB::table("estimates")
						// ->leftJoin("items","items.id", "=", "estimates.item_id")
						// ->leftJoin("users","users.id", "=", "estimates.order_user_id")
						// ->get();
						// dd($query); //For checking



                });
            }

            /**
             * Reverse the migrations.
             *
             * @return void
             */
            public function down()
            {
                Schema::dropIfExists("estimates");
            }
        }
    