<?php
namespace App\Http\Requests;
use Illuminate\Validation\Rule;
use Illuminate\Foundation\Http\FormRequest;

//*************************************************************
// Rule
//1.  use App\Http\Requests\ProjectsValidation; //Add Controller
//2.  public function store( ProjectsValidation $request ){ //example
//*************************************************************

class ProjectsValidation extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true; //[ *1. default=false ]
    }
    
    
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        //[ *2. Validation rule description location ]
        return [
				"name" => "nullable|max:254", //string('name',254)->nullable()
				"makerid" => "nullable|integer", //integer('makerid')->nullable()
				"endline" => "nullable|date_format:Y-m-d H:i:s", //datetime('endline')->nullable()
				"total" => "nullable|integer", //integer('total')->nullable()
				"comment" => "nullable", //text('comment')->nullable()
				"status" => "nullable|integer", //integer('status')->nullable()

            ];
        }
    
        //[ *3. Set Validation message (*Optional) ]
        //Be sure to use [messages] for the Function name.
        //[Ja]https://readouble.com/laravel/6.x/ja/validation-php.html
        public function messages(){
            return [
                //"email.required"  => "メールアドレスを入力してください",
                //"email.max"       => "**文字以下で入力してください",
            ];
        }
    
    }



